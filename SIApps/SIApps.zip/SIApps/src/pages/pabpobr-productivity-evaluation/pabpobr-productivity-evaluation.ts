import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-pabpobr-productivity-evaluation',
  templateUrl: 'pabpobr-productivity-evaluation.html'
})
export class PABPOBRProductivityEvaluationPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    
  }

}
