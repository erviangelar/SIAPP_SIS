import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the PABPOBRBSNumOfFleetEvaluation page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-pabpobrbs-num-of-fleet-evaluation',
  templateUrl: 'pabpobrbs-num-of-fleet-evaluation.html'
})
export class PABPOBRBSNumOfFleetEvaluationPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad PABPOBRBSNumOfFleetEvaluationPage');
  }

}
