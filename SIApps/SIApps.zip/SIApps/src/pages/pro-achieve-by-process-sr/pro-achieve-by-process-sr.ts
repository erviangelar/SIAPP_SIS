import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the ProAchieveByProcessSR page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-pro-achieve-by-process-sr',
  templateUrl: 'pro-achieve-by-process-sr.html'
})
export class ProAchieveByProcessSRPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProAchieveByProcessSRPage');
  }

}
