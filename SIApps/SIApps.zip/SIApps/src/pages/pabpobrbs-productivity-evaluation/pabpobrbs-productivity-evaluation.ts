import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the PABPOBRBSProductivityEvaluation page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-pabpobrbs-productivity-evaluation',
  templateUrl: 'pabpobrbs-productivity-evaluation.html'
})
export class PABPOBRBSProductivityEvaluationPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad PABPOBRBSProductivityEvaluationPage');
  }

}
