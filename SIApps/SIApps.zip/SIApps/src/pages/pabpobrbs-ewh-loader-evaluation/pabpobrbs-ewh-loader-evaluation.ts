import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the PABPOBRBSEwhLoaderEvaluation page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-pabpobrbs-ewh-loader-evaluation',
  templateUrl: 'pabpobrbs-ewh-loader-evaluation.html'
})
export class PABPOBRBSEwhLoaderEvaluationPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad PABPOBRBSEwhLoaderEvaluationPage');
  }

}
