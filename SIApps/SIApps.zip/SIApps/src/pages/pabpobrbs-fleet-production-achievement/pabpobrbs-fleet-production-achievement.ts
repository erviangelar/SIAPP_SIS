import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the PABPOBRBSFleetProductionAchievement page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-pabpobrbs-fleet-production-achievement',
  templateUrl: 'pabpobrbs-fleet-production-achievement.html'
})
export class PABPOBRBSFleetProductionAchievementPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad PABPOBRBSFleetProductionAchievementPage');
  }

}
