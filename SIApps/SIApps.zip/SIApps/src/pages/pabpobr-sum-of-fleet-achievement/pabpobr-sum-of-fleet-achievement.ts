import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-pabpobr-sum-of-fleet-achievement',
  templateUrl: 'pabpobr-sum-of-fleet-achievement.html'
})
export class PABPOBRSumOfFleetAchievementPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    
  }

}
