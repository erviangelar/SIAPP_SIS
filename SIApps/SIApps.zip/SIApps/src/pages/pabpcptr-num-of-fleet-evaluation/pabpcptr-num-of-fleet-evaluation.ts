import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the PABPCPTRNumOfFleetEvaluation page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-pabpcptr-num-of-fleet-evaluation',
  templateUrl: 'pabpcptr-num-of-fleet-evaluation.html'
})
export class PABPCPTRNumOfFleetEvaluationPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad PABPCPTRNumOfFleetEvaluationPage');
  }

}
