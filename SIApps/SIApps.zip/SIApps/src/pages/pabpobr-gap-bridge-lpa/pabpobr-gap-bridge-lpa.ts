import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-pabpobr-gap-bridge-lpa',
  templateUrl: 'pabpobr-gap-bridge-lpa.html'
})
export class PABPOBRGapBridgeLPAPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    
  }

}
