import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';


@Component({
  selector: 'page-pabpobr-pro-achievement-by-pit',
  templateUrl: 'pabpobr-pro-achievement-by-pit.html'
})
export class PABPOBRProAchievementByPitPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    
  }

}
