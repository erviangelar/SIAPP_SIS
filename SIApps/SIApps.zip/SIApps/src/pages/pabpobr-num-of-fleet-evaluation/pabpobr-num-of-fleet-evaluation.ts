import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-pabpobr-num-of-fleet-evaluation',
  templateUrl: 'pabpobr-num-of-fleet-evaluation.html'
})
export class PABPOBRNumOfFleetEvaluationPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    
  }

}
