import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-pabpobr-ewh-loader-evaluation',
  templateUrl: 'pabpobr-ewh-loader-evaluation.html'
})
export class PABPOBREwhLoaderEvaluationPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    
  }

}
